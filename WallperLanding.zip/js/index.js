
$(document).ready(function (e) {
$('#slider1').slider({ showInstruction: false });
    $('#slider2').slider({ showInstruction: false });
    $('#slider3').slider({ showInstruction: false });
    });